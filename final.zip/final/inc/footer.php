<footer class="container-fluid p-4 clearfix">
    <marquee behavior="" direction="">
    <div class="container clearfix">
        <a class="float-left text-dark" href="#">E-shopping</a>
        <a class="float-left ml-3 text-dark" href="#">Privacy Policy</a>
        <p class="float-right">Copyright © 2022 |  Made in ❤️ <b>E-commerce Subject</b> </p>
    </div>  
    </marquee>
</footer>