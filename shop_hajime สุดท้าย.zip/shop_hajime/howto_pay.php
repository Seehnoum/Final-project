<?php require_once "header.php";?>

		<!--//sreen-gallery-cursual---->
	<div class="content-grids">

	<h2 class="alert">วิธีการชำระเงิน</h2>

  <hr>
	

	<div class="col-md-12 content-grid">
		
ใส่ข้อมูล
		</div>

		<div class="clearfix"> </div>

	</div>

	<div class="clearfix"> </div>
	</div>
	<!---->

<?php require_once "footer.php";?>

</body>
</html>