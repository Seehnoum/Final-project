<?php require_once "header.php";?>

		<!--//sreen-gallery-cursual---->
	<div class="content-grids">

	<h2 class="alert">ติดต่อเรา</h2>

  <hr>
	

	<div class="col-md-12 content-grid">
		<h3><?php echo $contact_web;?></h3>
		</div>

		<div class="clearfix"> </div>

	</div>

	<div class="clearfix"> </div>
	</div>
	<!---->

<?php require_once "footer.php";?>

</body>
</html>